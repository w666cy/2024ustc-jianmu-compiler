#!/bin/bash
rm -rf output log.txt
