#!/bin/bash

python3 eval_lab2.py
