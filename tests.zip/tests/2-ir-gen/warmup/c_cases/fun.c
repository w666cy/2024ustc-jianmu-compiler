int callee(int a) { return 2 * a; }
int main() { return callee(110); }
