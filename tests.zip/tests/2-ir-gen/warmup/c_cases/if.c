int main() {
    float a = 5.555;
    if (a > 1)
        return 233;
    return 0;
}
