#include "BasicBlock.hpp"
#include "Constant.hpp"
#include "Function.hpp"
#include "IRBuilder.hpp"
#include "Module.hpp"
#include "Type.hpp"

#include <iostream>
#include <memory>

#define CONST_INT(num) ConstantInt::get(num, module)
#define CONST_FP(num) ConstantFP::get(num, module)

// int main() {
//     int a;
//     int i;
//     a = 10;
//     i = 0;
//     while (i < 10) {
//         i = i + 1;
//         a = a + i;
//     }
//     return a;
// }

int main() {
    auto module = new Module();
    auto builder = new IRBuilder(nullptr, module);

    Type *Int32Type = module->get_int32_type();

    auto mainFun =
        Function::create(FunctionType::get(Int32Type, {}), "main", module);
    auto bb = BasicBlock::create(module, "entry", mainFun);
    builder->set_insert_point(bb);

    auto aAlloca = builder->create_alloca(Int32Type);
    auto iAlloca = builder->create_alloca(Int32Type);
    builder->create_store(CONST_INT(10), aAlloca);
    builder->create_store(CONST_INT(0), iAlloca);

    auto whileBB = BasicBlock::create(module, "whileBB", mainFun);
    builder->create_br(whileBB);

    builder->set_insert_point(whileBB);
    auto iLoad = builder->create_load(iAlloca);
    auto icmp = builder->create_icmp_lt(iLoad, CONST_INT(10));
    auto trueBB = BasicBlock::create(module, "trueBB", mainFun);
    auto falseBB = BasicBlock::create(module, "falseBB", mainFun);
    builder->create_cond_br(icmp, trueBB, falseBB);

    builder->set_insert_point(trueBB);
    iLoad = builder->create_load(iAlloca);
    auto add1 = builder->create_iadd(iLoad, CONST_INT(1));
    builder->create_store(add1, iAlloca);
    auto aLoad = builder->create_load(aAlloca);
    iLoad = builder->create_load(iAlloca);
    auto add2 = builder->create_iadd(aLoad, iLoad);
    builder->create_store(add2, aAlloca);
    builder->create_br(whileBB);

    builder->set_insert_point(falseBB);
    aLoad = builder->create_load(aAlloca);
    builder->create_ret(aLoad);

    std::cout << module->print();
    delete module;
    return 0;
}
