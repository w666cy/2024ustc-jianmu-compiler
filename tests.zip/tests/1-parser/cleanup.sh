#!/bin/sh
rm -rf output_student/*
rm -rf output_student_ast/*
